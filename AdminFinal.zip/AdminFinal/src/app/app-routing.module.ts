import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';
import { InventoryDetailsComponent } from './inventory-details/inventory-details.component';
import { CommonModule } from '@angular/common';
import { CouponComponent } from './coupon/coupon.component';
import { OptionpageComponent } from './optionpage/optionpage.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { SendInvitationComponent } from './send-invitation/send-invitation.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ReturnpageComponent } from './returnpage/returnpage.component';

import { RefundComponent } from './refund/refund.component';
import { ReturnmessageComponent } from './returnmessage/returnmessage.component';
import { ReportComponent } from './report/report.component';

import { AddreportComponent } from './addreport/addreport.component';

const routes: Routes = [
  { path: '', redirectTo: 'customerdetails', pathMatch: 'full' },
  { path: 'customerdetails', component: CustomerDetailsComponent},
  { path: 'merchantdetails', component: MerchantDetailsComponent },
  { path: 'inventorydetails', component: InventoryDetailsComponent },
  { path: 'couponsandpromos', component: CouponComponent },
  { path: 'options', component: OptionpageComponent, pathMatch: 'full' },
  { path: 'add-merchant', component: AddMerchantComponent, pathMatch: 'full' },
  { path: 'delete-merchant', component: DeleteMerchantComponent, pathMatch: 'full' },
  { path: 'send-invitation', component: SendInvitationComponent, pathMatch: 'full' },
  { path: 'refund', component : RefundComponent ,pathMatch: 'full'},
  { path: 'return', component : ReturngoodsComponent },
  { path: 'returnpage', component : ReturnpageComponent},
  { path: 'returnmessage', component : ReturnmessageComponent ,pathMatch: 'full'},
  { path: 'report', component: ReportComponent },
  { path: 'addreport', component: AddreportComponent },
  { path: '**', redirectTo: '', pathMatch: 'full'}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
