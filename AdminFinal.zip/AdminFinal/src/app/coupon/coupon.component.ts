import { Component, OnInit, Input } from '@angular/core';
import { CouponFields } from '../model/add-coupon';

import { Router } from '@angular/router';
import { CouponService } from '../service/coupon.service';
import { FormGroup } from '@angular/forms';
import * as moment from 'moment';
@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.css']
})
export class CouponComponent {
  date = new Date();
  coup: CouponFields;
  addData: FormGroup;
  selectedDate;
  formattedDate;
  constructor(private cserv: CouponService, private router: Router) {
    this.coup = new CouponFields();
}

// convert date picker format to DD/MM/YYYY
sendCouponDetails() {
  const momentDate = new Date(this.selectedDate);
  this.formattedDate = moment(momentDate).format('MM/DD/YYYY');
  this.coup.couponExpiry = this.formattedDate;
  this.cserv.add(this.coup).subscribe(
    result => {
      console.log(result);
      // if  result is success the display alert
      // alert("Coupon generated successfullly");
    },
    error => {
      console.log(error);
    }
  );
}
}
