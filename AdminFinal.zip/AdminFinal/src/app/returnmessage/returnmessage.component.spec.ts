import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnmessageComponent } from './returnmessage.component';

describe('ReturnmessageComponent', () => {
  let component: ReturnmessageComponent;
  let fixture: ComponentFixture<ReturnmessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReturnmessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnmessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
