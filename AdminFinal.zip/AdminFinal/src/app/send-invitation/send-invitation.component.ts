import { Component, OnInit } from '@angular/core';
import { MerchantServiceService } from '../Service/merchant-service.service';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-send-invitation',
  templateUrl: './send-invitation.component.html',
  styleUrls: ['./send-invitation.component.css']
})
export class SendInvitationComponent implements OnInit {
  mobile: number;
  mobileNoControl =  new FormControl('',[Validators.required, Validators.pattern('^[0-9]{10}')]);
  constructor(private merchantService: MerchantServiceService, private router: Router) {

    
  }

  ngOnInit() {
  }

  send() {

    this.merchantService.sendInvitation(this.mobile).subscribe(
      result => {
        console.log(result);
        console.log("Added Successfully");
        alert("Sent Invitation Successfully");
        this.router.navigate(['/merchantdetails']);
      }, error => { console.log(error),alert("Failed") }
    )
    
    
  
  }
}
