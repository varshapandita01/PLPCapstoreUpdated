import { Component, OnInit } from '@angular/core';
import { Merchant } from '../model/ManageMerchant';
import { MerchantServiceService } from '../Service/merchant-service.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-delete-merchant',
  templateUrl: './delete-merchant.component.html',
  styleUrls: ['./delete-merchant.component.css']
})
export class DeleteMerchantComponent implements OnInit {

  id: number;
  merchant = new Merchant();
  merchantArr: Merchant[] = [];
  constructor(private merchantService: MerchantServiceService) {
   
  }

  ngOnInit() {
    this.id = 0;
  }

 
  searchMerchant() {
    
    this.merchantService.searchMerchant(this.id).subscribe(merchant => { this.merchant = merchant }
      
      , error => {
        console.log(error)
        alert("No Such id Found")
        
      })
      this.merchant = new Merchant();
  }

  delete() {
    this.merchantService.delete(this.merchant.id).subscribe(
      res => {
        console.log("Deleted succesfully")
      }, error => { console.log(error) }
    )
    alert("Data Deleted Successfully")
    this.merchant = new Merchant();
  }
  
}
