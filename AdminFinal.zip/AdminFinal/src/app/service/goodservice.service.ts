import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { InventoryModel } from '../model/inventory';

@Injectable({
  providedIn: 'root'
})
export class GoodserviceService {

  constructor(private http: HttpClient) { }
  baseurl ="http://localhost:8080";
  

  getAll(){
// return this.http.get<inventory[]>(this.baseurl +"/all");
return this.http.get<InventoryModel[]>(this.baseurl + "/product/all");

  }
}
