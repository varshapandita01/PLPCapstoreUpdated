import { Product } from './Product';

export class MostView{

  id:number;
  viewCount:number;
  soldCount:string;
  productFromMostView:Product;

}
