package com.capstore.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Merchant;
import com.capstore.dao.MerchantDao;

@Repository
@Transactional
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantDao dao;

	@Override
	public void saveMerchant(Merchant merchant) {
		
		dao.save(merchant);
	}

	@Override
	public Merchant findById(int id) {

		return dao.findById(id).get();
	}

	@Override
	public String deleteMerchant(int id) {

		dao.deleteById(id);
		return "Merchant Deleted Successfully";
	}

}
