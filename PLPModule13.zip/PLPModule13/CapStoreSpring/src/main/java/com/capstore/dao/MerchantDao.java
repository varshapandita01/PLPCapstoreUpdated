package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Merchant;


public interface MerchantDao extends CrudRepository<Merchant, Integer> {

}
