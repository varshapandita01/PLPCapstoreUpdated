package com.capstore.service;

import java.util.Optional;

import com.capstore.bean.Merchant;

public interface MerchantService {
	void saveMerchant(Merchant merchant);

	Merchant findById(int id);

	public String deleteMerchant(int id);
}
